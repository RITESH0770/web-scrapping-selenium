# Selenium-Webscraping-Example

### Description
In this tutorial we will build a web scraping program that will scrape a Github user profile and get the Repository names and the Languages for the pinned repositories.

### Resources
We will leverage these Resources
* [Selenium](https://pypi.python.org/pypi/selenium)
* [ChromeDriver - WebDriver for Chrome](https://sites.google.com/a/chromium.org/chromedriver/downloads)
* [Selenium-Python ReadTheDocs](http://selenium-python.readthedocs.io/)
